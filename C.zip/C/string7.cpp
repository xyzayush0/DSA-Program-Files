#include <stdio.h>
#include <ctype.h>
#include <string.h>
int main(){
	char a[100];
	int i,j,s=0;
	printf("Enter a String=");
	gets(a);
	for (i=0;a[i]!='\0';i++){
		if (isdigit(a[i])){
			s+=a[i]-48;
		}
	}
	printf("Sum=%d",s);
	
	
}
