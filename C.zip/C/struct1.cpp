#include <stdio.h>
struct cuboid{
	int l;
	int b;
	int h;
};
int main(){
	struct cuboid s1;
	printf("\n Enter length,breadth and height=");
	scanf("%d %d %d",&s1.l,&s1.b,&s1.h);
	int volume=s1.h * s1.b * s1.l;
	printf("Volume= %d",volume); 
}
