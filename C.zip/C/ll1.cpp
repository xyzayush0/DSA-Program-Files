#include <stdio.h>
#include <stdlib.h>

struct node
{
    int info;
    struct node *next;
};

struct node *start = NULL;

void create(int n)
{
    struct node *tmp, *i;
    tmp=(struct node *)malloc(sizeof(struct node));
    tmp->info = n;
    tmp->next = NULL;
    if (start == NULL)
    {
        start = tmp;
    }
    else
    {
        i = start;
        while (i->next != NULL)
        {
            i = i->next;
        }
        i->next = tmp;
    }
}

void show()
{
    struct node *i=start;
    while (i != NULL)
    {
        printf("%4d",i->info);
        i = i->next;
    }
}

void swap(int data)
{
    struct node *j,*i,*tmp;
    tmp=NULL;
    i=start;
    j=NULL;
    while (i!= NULL && i->next!=NULL)
    {
        j=i->next;
        i->next=j->next;
        j->next=i;
        if (tmp==NULL){
            start=j;
        }
        else{
            tmp->next=j;
        }
        tmp=i;
        i=i->next;
    }
}
int main()
{
    int a[]={50,21,9,31,45,60,7,12,10,87};
    int n=10,i,k,p;
    for (i = 0; i < n; i++)
    {
        create(a[i]);
    }
    printf("\nBefore Change List is : ");
    show();
    swap(k);
    printf("\nAfter change list=");
    show();

}
