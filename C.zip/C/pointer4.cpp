#include <stdio.h>
#include <ctype.h>
#include <string.h>
void rev(char *p){
	char *q=p;
	char t;
	while (*q!='\0'){
		q++;
	}
	q--;
	while(p<q)
	{
		t=*p;
		*p=*q;
		*q=t;
		
		p++;
		q--;
	}
}
int main(){
	int i;
	char s[100];
	printf("Enter a string");
	gets(s);
	rev(s);
	printf("%s",s);
	
}
