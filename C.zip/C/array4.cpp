#include <stdio.h>
void input(int a[],int n){
	int i;
	for (i=0;i<n;i++){
		scanf("%d",&a[i]);
	}
}
void output(int c[],int k){
	int i;
	for (i=0;i<k;i++){
		printf("%4d",c[i]);
	} 
}
void merge(int a[],int b[],int c[],int n,int m){
	int i=0;
	for (i=0;i<n;i++){
		c[i]=a[i];
	}
	for (i=0;i<m;i++){
		c[n+i]=b[i];
	}
}
int main(){
	int a[10],b[10],c[10];
	int n,m,k;
	printf("Enter Size of first Array:");
	scanf("%d",&n);
	printf("\nEnter Size of Second Array:");
	scanf("%d",&m);
	printf("\nEnter elements of array 1:");
	input(a,n);
	printf("Enter elements of second array:");
	input(b,m);
	merge(a,b,c,n,m);
	k=m+n;
	output(c,k);
	return 0;
	
	
	
}
