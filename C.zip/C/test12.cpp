#include <stdio.h>
#include <stdlib.h>

struct node
{
    int info;
    struct node *next;
};

struct node *start = NULL;

void create(int n)
{
    struct node *tmp, *i;
    tmp = (struct node *)malloc(sizeof(struct node));
    tmp->info = n;
    tmp->next = NULL;
    if (start == NULL)
    {
        start = tmp;
    }
    else
    {
        i = start;
        while (i->next != NULL)
        {
            i = i->next;
        }
        i->next = tmp;
    }
}

void show()
{
    struct node *i = start;
    while (i != NULL)
    {
        printf("%d ", i->info);
        i = i->next;
    }
}
float avg(){
	int aver=0;
	float c=0;
	struct node *i = start;
    while (i != NULL)
    {
        aver+=i->info;
        c++;
        i = i->next;
    }
    return aver/c;
}
void change(){
    struct node *i1,*i2;
    i1=start;
    i2=start;
    while (i2->next!= NULL)
    {
        i2=i2->next;
    }
    int temp=i1->info;
    i1->info=i2->info;
    i2->info=temp;
}

int main()
{
    int a[]={50,21,9,31,45,60,7,12,10,87};
    int n=10,i;
    float aver;
    for (i = 0; i < n; i++)
    {
        create(a[i]);
    }
    printf("\nBefore Change List is : ");
    show();
    aver=avg();
    printf("\nAverage = %.4f",aver);
    printf("\nAfter change list=");
    change();
    show();

}
