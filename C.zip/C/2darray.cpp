#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main(){
	int a[3][3],t[3][3];
	int i,index,max,j,s=0;
	srand(time(0));
	for (i=0;i<3;i++){
		for (j=0;j<3;j++){
			a[i][j]=rand()%100;
		}
	}
	printf("Before Transpose=\n");
	for (i=0;i<3;i++){
		for (j=0;j<3;j++){
			printf("%4d",a[i][j]);
			t[j][i]=a[i][j];
		}
		printf("\n");
	}
	printf("After Transpose=\n");
	for (i=0;i<3;i++){
		for (j=0;j<3;j++){
			printf("%4d",t[i][j]);
		}
		printf("\n");
	}
	
	return 0;
}
