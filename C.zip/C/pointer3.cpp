#include <stdio.h>
int main(){
	int m=5,n=6;
	int *p1,*p2;
	int **q;
	p1=&n;
	p2=&n;
	q=&p1;
	printf("%d %d %d %d %d\n",m,n,*p1,*p2,**q);
}
