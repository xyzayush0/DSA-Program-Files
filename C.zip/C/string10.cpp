#include <stdio.h>
#include <string.h>
#include <ctype.h>
int main(){
	char keypad[10][5] = {" ","","ABC","DEF", "GHI","JKL", "MNO","PQRS","TUV","WXYZ"};
	int x[][2]={{4,2},{3,2},{5,3},{5,3},{6,3}};
	char b[100];
	int i=0,j=0,digit,c,k=0;
	for (i=0;i<5;i++){
		digit=x[i][0];
		c=x[i][1];
		b[i]=keypad[digit][c-1];
	}
    printf("\n%s",b);
}
	
