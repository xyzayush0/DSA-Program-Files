#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct node
{
    int roll;
    char name[50];
    int marks;
    struct node *next;
};

struct node *start = NULL;

void create(int roll, char name[], int marks)
{
    struct node *tmp, *i;
    tmp = (struct node *)malloc(sizeof(struct node));
    tmp->roll = roll;
    strcpy(tmp->name, name);
    tmp->marks = marks;
    tmp->next = NULL;
    if (start == NULL)
    {
        start = tmp;
    }
    else                             
    {
        i = start;
        while (i->next != NULL)
        {
            i = i->next;
        }
        i->next = tmp;
    }
}

void show()
{
    struct node *i = start;
    printf("\nRoll\tName\tMarks\n");
    while (i != NULL)
    {
        printf("%d\t%s\t%d\n", i->roll, i->name, i->marks);
        i = i->next;
    }
}

void sort(){
    struct node *i,*j;;
    int tempRoll,tempMarks;
    char tempName[50];
    if (start==NULL || start->next==NULL){
        printf("\nNot possible to sort");
        return;
    }
    for (i=start;i!=NULL;i=i->next){
       for (j=i->next;j!=NULL;j=j->next){
        if (i->marks>j->marks){
            tempRoll=i->roll;
            strcpy(tempName, i->name);
            tempMarks=i->marks;

            i->roll=j->roll;
            strcpy(i->name, j->name);
            i->marks=j->marks;

            j->roll=tempRoll;
            strcpy(j->name, tempName);
            j->marks=tempMarks;
        }
       }
    }
    
}
int main()
{
    int roll[] = {1, 2, 3};
    char name[][20] = {"Arya", "Arjun", "Akash"};
    int marks[] = {89, 91, 78};
    int n = 3, i;
    for (i = 0; i < n; i++)
    {
        create(roll[i], name[i], marks[i]);
    }
    show();
    sort();
    show();
    return 0;
}