//Create a node Student with roll, name ,marks intialise 3 student details and display it.
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
struct node
{
    int roll;
    char name[50];
    int marks;
    struct node *next;
};

struct node *start = NULL;

void create(int n,char name[],int m)
{
    struct node *tmp, *i;
    tmp = (struct node *)malloc(sizeof(struct node));
    tmp->roll=n;
    strcpy(tmp->name, name);
    tmp->marks=m;
    tmp->next = NULL;
    if (start == NULL)
    {
        start = tmp;
    }
    else
    {
        i = start;
        while (i->next != NULL)
        {
            i = i->next;
        }
        i->next = tmp;
    }
}

void show()
{
    struct node *i = start;
    while (i != NULL)
    {
        printf("%d ", i->roll);
        printf("%s",i->name);
        printf("%d",i->marks);
        i = i->next;
    }
}
int main()
{
    int a[]={1,2,3};
    char c[][20]={"Arya","Arjun","Akash"};
    int k[]={89,91,78};
    int i;
    for (i = 0; i < 3; i++)
    {
        create(a[i],c[i][20],k[i]);
    }
    printf("\nList is : ");
    show();

}