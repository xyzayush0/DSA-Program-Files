//waf that accepets a 1d array and a size 
//1 for ascending 
//-1 for des
//0 for unsorted
#include <stdio.h>
void func(int a[],int n,int c=0){
	int i,m=0;
	for (i=0;i<n-1;i++){
		if (a[i]<a[i+1]){
			m+=1;
		}
		else if (a[i]>a[i+1]){
			m-=1;
		}
	}
	printf("%d %d",m,n);
	if (m==n-1){
		c+=1;
	}
	if (m==(n-1)*(-1)){
		c+=-1;
	}
}
int main(){
	int n,c,j,a[10];
	printf("\nEnter the number of elements=");
	scanf("%d",&n);
	printf("\nEnter elements of the array=");
	for (j=0;j<n;j++){
		scanf("%d",&a[j]);
	}
	func(a,n,c);
	printf("Output=%d",c);
	return 0;
}
