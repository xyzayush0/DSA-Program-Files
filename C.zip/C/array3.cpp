//Dec to Bin
#include <stdio.h>
int main(){
	int n,m,r,i=0;
	int a[15];
	printf("Enter Decimal Number=");
	scanf("%d",&n);
	while (n>0){
		r=n%2;
		a[i]=r;
		n=n/2;
		i++;
	}
	for (m=i-1;m>=0;m--){
		printf("%d",a[m]);
	}
	return 0;
	
}

