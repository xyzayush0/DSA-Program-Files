#include <stdio.h>
int main(){
	int w,a=0;
	int r=0;
	printf("Enter weight=");
	scanf("%d",&w);
	if (w>100){
		r=r+80;
		w=w-100;
		printf("\n First 100gm $80");
		while (w>100){
			r=r+40;
			w=w-100;
			a+=1;
		}
		printf("\n Next %d gm=$%d",a*100,a*40);
		printf("\n Next %d gm=$40",w);
		r+=40;
	}
		
	else{
		printf("\n First 100gm=$80");
		r+=80;
	}
	printf("\n Total=$%d",r);
	return 0;
	
}
