#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
int main(){
	char a[100],tmp[20];
	int i,j=0,s=0;
	printf("Enter a String=");
	gets(a);
	strcat(a," ");
	for (i=0;a[i]!='\0';i++){
		if (a[i]!=32){
			tmp[j++]=a[i];
		}
		else{
			tmp[j]='\0';
			s+=atoi(tmp);
			j=0;
		}
	}
	printf("Sum=%d",s);
}
