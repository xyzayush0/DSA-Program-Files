#include <stdio.h>
int main(){
	int a,b;
	printf("Enter two numbers=\n");
	scanf("%d %d",&a,&b);
	printf("Summation=%d\n",a+b);
	printf("Difference=%d\n",a-b);
	return 0;
}

