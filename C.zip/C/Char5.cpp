#include <stdio.h>
#include <ctype.h>
int main(){
	char a[][10] = {"Zero","One","Two","Three","Four","Five","Six","Seven","Eight","Nine"};
	int n,i,rev=0;
	printf("Enter Number=");
	scanf("%d",&n);
	while (n > 0) {
        rev = rev * 10 + (n % 10);
        n = n / 10;
    }
    while (rev > 0) {
        i=rev % 10;
        printf("%s ",a[i]);
        rev = rev/10;
    }
}
