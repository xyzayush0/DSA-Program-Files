#include <stdio.h>
int main()
{
    int si(int ,int , int );
    int p,r,t,s;
    printf("\nenter  p,r,t");
    scanf("%d%d%d",&p,&r,&t);
    s=(p*r*t)/100;
    printf("\nsi=%d",s);
}
int si(int x, int y, int z)
{
    int si=(x*y*z)/100;
    return si;
}
