#include <stdio.h>
#include <math.h>
#include <stdlib.h>
void bubbleSort(float arr[], int n) {
    for (int i = 0; i < n - 1; i++) {
        for (int j = 0; j < n - i - 1; j++) {
            if (arr[j] > arr[j + 1]) {
                int temp = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = temp;
            }
        }
    }
}
int main(){
	int x[10][2];
	float ind[10];
	int i,j;
	float c;
	
	for (i=0;i<10;i++){
		printf("Enter %d x,y=",i+1);
		scanf("%d %d",&x[i][0],&x[i][1]);	
	}
	for (i=1;i<10;i++){
		c=sqrt((x[i][0]-x[0][0])*(x[i][0]-x[0][0])+(x[i][1]-x[0][1])*(x[i][1]-x[0][1]));
		ind[i-1]=c;
	}
	bubbleSort(ind,9);
	for (i=0;i<9;i++){
		for (j=1;j<10;j++){
			c=sqrt((x[j][0]-x[0][0])*(x[j][0]-x[0][0])+(x[j][1]-x[0][1])*(x[j][1]-x[0][1]));
			if (ind[i]==c){
				printf("%d %d",&x[i][0],&x[i][1]);
			}
		}
	}
	return 0;
}
