#include <stdio.h>
void rev(int *p1,int n){
	int *p=p1,*p2=&p1[n-1];
	while(p<p2)
	{
		int temp=*p;
		*p=*p2;
		*p2=temp;
		
		p++;
		p2--;
	}
}
int main(){
	int b[]={10,20,30,40,50};
	int i;
	rev(&b[0],5);
	for (i=0;i<5;i++){
		printf(" %d ",b[i]);
	}
	
}
