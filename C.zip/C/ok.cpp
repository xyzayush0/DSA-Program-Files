#include <stdio.h>
int main(){
	int a,b=0,n,c,k;
	int i,pow=0;
	printf("Enter a number=");
	scanf("%d",&a);
	n=a;
	while (n!=0){
		pow++;
		n=n/10;
	}
	n=a;
	while (n!=0){
		k=n%10;
		c=1;
		for (i=0;i<pow;i++){
			c=c*k;
		}
		b=b+c;
		n=n/10;
	}
	if (a==b){
		printf("Yes");
		return 0;
	}
	printf("%d %d Not",&a,&b);
	return 0;	
}
