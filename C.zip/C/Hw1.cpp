//Sorted
#include <stdio.h>
int check(int a[],int n){
	int i,c1=0,c2=0;
	for (i=0;i<n-1;i++){
		if (a[i]<a[i+1]){
			c1+=1;
		}
		if (a[i]>a[i+1]){
			c2+=1;
		}
	}
	if (c1!=0 && c2!=0){
		return 0;
	}
	else if(c1==0){
		return -1;
		
	}
	else{
		return 1;
	}
}
void sort(int a[],int n){
	int i,j,tmp;
	for (i=0;i<n-1;i++){
		for (j=0;j<n-i-1;j++){
			if (a[j]>a[j+1]){
				tmp=a[j];
				a[j]=a[j+1];
				a[j+1]=tmp;
			}
		}
	}
}
void merge(int a[],int b[],int c[],int n,int m){
	int i=0;
	for (i=0;i<n;i++){
		c[i]=a[i];
	}
	for (i=0;i<m;i++){
		c[n+i]=b[i];
	}
}
void input(int a[],int n){
	int i;
	printf("\nEnter elements of the array=");
	for (i=0;i<n;i++){
		scanf("%d",&a[i]);
	}
}
void output(int a[],int n){
	int i;
	for (i=0;i<n;i++){
		printf("%4d",a[i]);
	}
}
int main(){
	int m,n,a[10],b[10],c[10];
	printf("Enter length of array 1=");
	scanf("%d",&n);
	printf("Enter in ascending order=");
	input(a,n);
	if (check(a,n)!=1){
		printf("The Enter array is not in ascending order!!!");
		return 0;
	}
	printf("Enter length of array 2=");
	scanf("%d",&m);
	printf("Enter in descending order=");
	input(b,m);
	if (check(b,m)!=-1){
		printf("The Enter array is not in descending order!!!");
		return 0;
	}	
	merge(a,b,c,n,m);
	sort(c,m+n);
	output(c,m+n);
	return 0;
	
}
