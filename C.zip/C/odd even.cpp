#include <stdio.h>
int main(){
	int n,m,i,j;
	printf("Enter N=");
	scanf("%d",&n);
	for (i=0;i<n;i++){
		for (j=0;j<n-i;j++){
			printf("*");
		}
		printf("\n");
	}
}

