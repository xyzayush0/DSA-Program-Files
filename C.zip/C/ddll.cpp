#include<stdio.h>
#include<stdlib.h>
struct node{
	int info;
	struct node *prev,*next;
}*head=NULL;

void create(int n){
	struct node *i,*temp=(struct node *)malloc(sizeof(struct node));
	temp->info=n;
	temp->next=NULL;
	if(head==NULL){
		head=temp;
		temp->prev=NULL;
	}
	else{
		i=head;
		while(i->next!=NULL)
		i=i->next;
		i->next=temp;
		temp->prev=i;
	}
}

void insert(int val){
	struct node *i=head,*temp=(struct node *)malloc(sizeof(struct node));;
	temp->info=val;
    if(val<=head->info){
        temp->next=head;
        temp->prev=NULL;
        head->prev=temp;
        head=temp;
        return;
    }
	while (i->next!=NULL){
		if (i->info<=val && i->next->info>=val){
			temp->prev=i;
			temp->next=i->next;
			i->next->prev=temp;
			i->next=temp;
			return;
		}
		i=i->next;
	}
	i->next=temp;
	temp->prev=i;
	temp->next=NULL;
}


void display(){
	struct node *i=head;
	while(i->next!=NULL){
		printf("%3d",i->info);
		i=i->next;
	}
	printf("%3d\n\n",i->info);
	while(i!=NULL){
		printf("%3d",i->info);
		i=i->prev;
	}
}

int main(){
	int i;
	for(i=10;i<100;i+=10){
		create(i);
	}
	display();
    insert(250);
    printf("\n \n");
    display();
}
