#include <stdio.h>
#include <stdlib.h>
#define size 15
int stk[size];
int top=-1;
void push(int value)
{
    if (top == size - 1)
    {
        printf("Stack Overflow");
        return;
    }

    stk[++top] = value;
}
void show()
{
    int i;
    printf("\nStack Status:\n");
    if (top==-1)
    {
        printf("Stack is Empty");
        return;
    }
    for (i=top;i>=0;i--)
    {
        printf("%4d", stk[i]);
    }
}
int main(){
	int n;
	printf("Enter the number=");
	scanf("%d",&n);
	while (n>0) {
        push(n%2); 
        n=n/2;            
    }
    show();
    return 0;
}
