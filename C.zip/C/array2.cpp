#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main(){
	int a[50];
	int b[50];
	srand(time(0));
	int n,m,i,j,k=0,c=0;
	for (i=0;i<50;i++){
		n=rand()%100;
		a[i]=n;
	}
	for (i=0;i<50;i++){
		m=a[i];
		k=0;
		for (j=0;j<50;j++){
			if (b[j]==m){
				k+=1;
			}
		}
		if (k==0){
			b[c]=m;
			c+=1;
		}
	}
	printf("\n Old Array=\n");
	for (i=0;i<50;i++){
		printf("%d,",a[i]);
	}
	printf("\n New Array=\n");
	for (i=0;i<=c;i++){
		printf("%d,",b[i]);
	}
	return 0;
	
}

