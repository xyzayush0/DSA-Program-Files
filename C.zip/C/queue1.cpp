#include <stdio.h>
#define size 5
int arr[size];
int rear=-1;
int front=0;
void enque(int value){
	if (rear==size-1){
		return;
	}
	arr[++rear]=value;
}
int dequeue(){
	if (rear<front){
		printf("Queue is empty");
		return 0;
	}
	int value=arr[front++];
	return value;
}
void show(){
	int i;
	for (i=front;i<=rear;i++){
		printf("%4d",arr[i]);
	}
}
int main(){
	int i,n,q;
	while (1){
		printf("Enter your choice \n 1.Add \n 2.Delete \n3.Leave \n");
		scanf("%d",&q);
		if (q==1){
			printf("Enter the value=");
			scanf("%d",&n);
			enque(n);
		}
		else if (q==2){
			n=dequeue();
			printf("%d",n);
		}
		else if (q==3){
			break;
		}
		else{
			printf("Wrong input Try again \n");
		}
	}
	show();
	return 0;
}
