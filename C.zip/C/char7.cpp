#include <stdio.h>
#include <ctype.h>
int main(){
	char a1[20]="Dennis";
	char a2[20]="Ritchie";
	int k=0,i=0;
	char s1[20],s2[20];
	for (i=0;i<3;i++){
		printf("\nWho is the Inventor of C?");
		scanf("%s %s",&s1,&s2);
		if (strcmp(a1,s1) && strcmp(s2,a2){
			printf("\nGOOD");
			k++;
			break;
			
		}
		else{
			printf("\nTry Again!!");
		}
	}
	if (k==0){
		printf("\nThe Answer Was= %s %s",a1,a2);
	}
	
}
