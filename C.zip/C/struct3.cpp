#include <stdio.h>
#include <string.h>
struct date{
	int day;
	int month;
	int year;
};
void input(struct date &s1){
	printf("\n Enter date month year=");
	scanf("%d %d %d",&s1.day,&s1.month,&s1.year);
}
void check(struct date &s1){
	int d[12]={31,28,31,30,31,30,31,31,30,31,30,31};
	int k=0;
	char m[12][10]={"January","February","March","April","May","June","July","August","September","October","November","December"};
	if (s1.day>d[s1.month-1]){
		printf("%d,%d,%d--%s has only %d days",s1.day,s1.month,s1.year,m[s1.month-1],d[s1.month-1]);
		k+=1;
	}
	if ((s1.year%4==0) && (s1.year%100!=0) || (s1.year%400==0)){
		printf("%d,%d,%d--%d is not a leap year",s1.day,s1.month,s1.year,s1.year);
		k+=1;
	}
	if (k==0){
		printf("%s %d,%d",m[s1.month-1],s1.day,s1.year);
	}

}
void nextdate(struct date &s1){
	int n;
	int d[12]={31,28,31,30,31,30,31,31,30,31,30,31};
	char m[12][10]={"January","February","March","April","May","June","July","August","September","October","November","December"};
	printf("\nEnter no of days to add=");
	scanf("%d",&n);
	s1.day+=n;
	if (s1.day>d[s1.month-1]){
		s1.month++;
		if ((s1.month)>12){
			s1.year++;
			s1.month=1;
		}
		s1.day-=d[s1.month-1];
	}
	printf("New Date=%s %d,%d",m[s1.month-1],s1.day,s1.year);
}
int main(){
	struct date s1;
	input(s1);
	check(s1);
	nextdate(s1);
	
}
