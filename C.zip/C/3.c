#include <stdio.h>
#include <stdlib.h>

struct node
{
    int info;
    struct node *next;
};

struct node *start = NULL;

void create(int n)
{
    struct node *tmp, *i;
    tmp = (struct node *)malloc(sizeof(struct node));
    tmp->info = n;
    tmp->next = NULL;
    if (start == NULL)
    {
        start = tmp;
    }
    else
    {
        i = start;
        while (i->next != NULL)
        {
            i = i->next;
        }
        i->next = tmp;
    }
}

void show()
{
    struct node *i = start;
    while (i != NULL)
    {
        printf("%d ", i->info);
        i = i->next;
    }
}

void rev(){
	struct node *i=NULL;
	struct node *j=start;
    struct node *k=NULL;    
	while (j!=NULL){
        k=j->next;
        j->next=i;
        i=j;
        j=k;
	}
    start=i;
}
int main()
{
    int a[]={50,21,9,31,45,60,7,12,10,87};
    int n=10,i;
    float aver;
    for (i = 0; i < n; i++)
    {
        create(a[i]);
    }
    printf("\nBefore Change List is : ");
    show();
    printf("\nAfter change list=");
    rev();
    show();

}