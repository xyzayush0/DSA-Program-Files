#include <stdio.h>
#include <string.h>
#include <ctype.h>
int main(){
	char a[100],b[100],t[100];
	printf("\nEnter First String=");
	gets(a);
	printf("\nEnter Second String=");
	gets(b);
	strcpy(t,a);
    strcpy(a,b);
    strcpy(b,t);
	printf("\nString 1= %s",a);
	printf("\nString 2= %s",b);
	
}
