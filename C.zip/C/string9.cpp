//was it a car a cat i saw
#include <stdio.h>
#include <string.h>
#include <ctype.h>
int main(){
	char a[100];
	char b[100];
	int i,j=0,n=0;
	printf("Enter your string=");
	gets(a);
	for (i=0;a[i]!='\0';i++){
		if (a[i]!=' '){
			b[j++]=tolower(a[i]);
			
		}
	}
	b[j]='\0';
	for (i=0;i<j/2;i++){
		if (b[i]!=b[j-i-1]){
			n++;
			break;
		}
	}
	if (n==0){
		printf("palindrome");
	}
	else{
		printf("not palindrome");
		
	}
}
