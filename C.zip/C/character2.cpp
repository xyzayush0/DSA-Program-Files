#include <stdio.h>
#include <ctype.h>
int main(){
	char s;
	printf("Enter the Character=");
	scanf("%c",&s);
	printf("\n");
	if (isalpha(s)){
		if (isupper(s)){
			printf("Alphabet-Upper");
			printf("\nLower:-\n%c",s+32);
		}
		else{
			printf("Alphabet-Lower");
			printf("\nUpper:-\n%c",s-32);
		}
	}
}
