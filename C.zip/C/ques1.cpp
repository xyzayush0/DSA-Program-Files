#include <stdio.h>
#include <ctype.h>
#include <string.h>
void sort(char s[]) {
    int i,j;
    char t;
    for (i =0;s[i]!='\0';i++){
        for (j=i+1;s[j]!='\0';j++) {
            if (s[i]>s[j]){
                t=s[i];
                s[i]=s[j];
                s[j]=t;
            }
        }
    }
}
int main(){
	char d[10][100];
	char s[10][100;]
	char a[10][100];
	int n,i,j,m=0;
	printf("How many strings=");
	scanf("%d",&n);
	for (i=0;i<n;i++){
		printf("\nEnter string=");
		scanf("%s",a[i]);
	}
	
	for (i=0;i<n;i++){
		strcpy(d[i],a[i]);
		sort(a[i]);
	}
	for (i=0;i<n;i++){
		int flag=0;
		for (j=i+1;j<n;j++){
			if (strcmpi(a[j],a[i])==0){
				printf(" %s ",d[j]);
				strcmp(s[i],d[j])
		}
		printf("\n");
	}

}
