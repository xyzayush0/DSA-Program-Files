#include <stdio.h>
#include <stdlib.h>
void bubble(int a[],int n){
	int i,j,tmp;
	for (i=0;i<n-1;i++){
		for (j=0;j<n-i-1;j++){
			if (a[j]>a[j+1]){
				tmp=a[j];
				a[j]=a[j+1];
				a[j+1]=tmp;
			}
		}
	}
}
void selection(int a[],int n){
	int i,j,tmp,small;
	for (i=0;i<n;i++){
		small=i;
		for (j=i+1;j<n;j++){
			if (a[j]<a[small]){
				small=j;
			}
		}
		if (small!=i){
			tmp=a[i];
			a[i]=a[small];
			a[small]=tmp;
		}
	}
}
void insertion(int a[],int n){
	int i,j,tmp;
	for (i=1;i<n;i++){
		tmp=a[i];
		j=i-1;
		while (tmp<a[j] && j>=0){
			a[j+1]=a[j];
			j--;
		}
		a[j+1]=tmp;
	}
}
void input(int a[],int n){
	int i;
	printf("\nEnter elements of the array=");
	for (i=0;i<n;i++){
		scanf("%d",&a[i]);
	}
}
void output(int a[],int n){
	int i;
	for (i=0;i<n;i++){
		printf("%4d",a[i]);
	}
}
int main(){
	int c,n,a[10];
	printf("\nEnter Your Choice \n1.Selection Sort\n2.Bubble Sort\n3.Insertion sort");
	scanf("%d",&c);
	printf("\nEnter Size of Array=\n");
	scanf("%d",&n);
	input(a,n);
	if (c==1){
		selection(a,n);
	}
	else if (c==2){
		bubble(a,n);
		
	}
	else if (c==3){
		insertion(a,n);
	}
	else{
		printf("\nInvalid Input");
	}
	output(a,n);
	
}

