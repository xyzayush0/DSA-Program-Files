//Frequency of each vowel
//Count number of vowels and consonents
#include <stdio.h>
void check(int k[6],char n){
	int i;
	char b[11]="AEIOUaeiou";
	for (i=0;i<5;i++){
		if (n==b[i] || n==b[i+5]){
			k[i]+=1;
		}
	}
}
int main(){
	int i,j,v=0,c=0;
	int k[11]={0,0,0,0,0,0,0,0,0,0,0};
	char a[100];
	char b[11]="AEIOU";
	printf("\n Enter the String=");
	gets(a);
	for (i=0;a[i]!='\0';i++){
		check(k,a[i]);
	}
	for (i=0;i<5;i++){
		printf("%c = %d \n",b[i],k[i]);
	}
}
