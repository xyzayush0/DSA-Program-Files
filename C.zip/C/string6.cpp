//Remove all vowels
//Count number of vowels and consonents
#include <stdio.h>
int check(char n){
	char b[11]="AEIOUaeiou";
	int i;
	for (i=0;i<10;i++){
		if (n==b[i]){
			return 1;
		}
	}
	return 0;
}
int main(){
	int i,j,v=0,c=0;
	char a[100];
	printf("\n Enter the String=");
	gets(a);
	for (i=0;a[i]!='\0';i++){
		if (a[i]>='A' && a[i]<='Z' || a[i]>='a' && a[i]<='z'){
			if (check(a[i])){
				for (j=i;a[j]!='\0';j++){
					a[j]=a[j+1];
				}
			}
		}
	}
	for (i=0;a[i]!='\0';i++){
		printf("%c",a[i]);
	}
}
