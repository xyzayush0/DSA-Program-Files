#include <stdio.h>
int main(){
	int i=0,j,k;
	char a[100];
	printf("Enter the String=");
	gets(a);
	printf("String in Reverse=");
	for (i=0;a[i]!='\0';i++);
	for (i=i-1;i>=0;i--){
		printf("%c",a[i]);
	}
}
