#include <stdio.h>
void input(int a[],int n){
	int i;
	printf("\nEnter elements of the array=");
	for (i=0;i<n;i++){
		scanf("%d",&a[i]);
	}
}
void output(int a[],int n){
	int i;
	for (i=0;i<n;i++){
		printf("%4d",a[i]);
	}
}int main(){
	int i=0,n,a[10],b[10];
	printf("\nEnter Size of Array=\n");
	scanf("%d",&n);
	input(a,n);
	while (i<n){
		if (a[i]%10==0){
			b[i]=a[i+1];
			b[i+1]=a[i];
			i+=2;
		}
		else{
			b[i]=a[i];
			i++;
		}
	}
	for (i=0;i<n;i++){
		a[i]=b[i];
	}
	output(a,n);
	return 0;
}

