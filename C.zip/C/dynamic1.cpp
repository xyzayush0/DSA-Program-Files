#include<stdio.h>
#include<stdlib.h>
int main()
{
	int **a,n,m,j,i;
	printf("\n Enter the row and column :");
	scanf("%d %d",&n,&m);
	a=(int **)malloc(sizeof(int)*n);
	for(i=0;i<n;i++){
		*(a+i)=(int *)malloc(sizeof(int)*m);
	}
	printf("\n Enter the elements:");
	for(i=0;i<n;i++)
	{
		for (j=0;j<m;j++){
			scanf("%d",(*(a+i)+j));
		}
	}
	printf("\n Elements are \n:");
	for(i=0;i<n;i++)
	{
		for (j=0;j<m;j++){
			printf("%4d",*(*(a+i)+j));
		}
		printf("\n");
	}
}
