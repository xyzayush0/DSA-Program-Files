#include <stdio.h>
#include <stdlib.h>
#define size 5

int stk1[size];
int stk2[size];
int top1=-1;
int top2=-1;

void push1(int value){
    if(top1==size-1){
        printf("Stack1 Overflow\n");
        return;
    }
    stk1[++top1]=value;
}

int pop1(){
    if(top1==-1){
        return -1;
    }
    return stk1[top1--];
}

void push2(int value){
    if(top2==size-1){
        printf("Stack2 Overflow\n");
        return;
    }
    stk2[++top2]=value;
}

int pop2(){
    if(top2==-1){
        return -1;
    }
    return stk2[top2--];
}

void queue(int value){
    push1(value);
}

int dequeue(){
    int value;
    if(top1==-1 && top2==-1){
        printf("Queue Empty\n");
        return -1;
    }
    if(top2==-1){
        while(top1!=-1){
            push2(pop1());
        }
    }
    value=pop2();
    return value;
}

void show(){
    int i;
    if(top1==-1 && top2==-1){
        printf("Queue Empty\n");
        return;
    }
    for(i=top2;i>=0;i--){
        printf("%d ",stk2[i]);
    }
    for(i=0;i<=top1;i++){
        printf("%d ",stk1[i]);
    }
    printf("\n");
}

int main(){
    queue(10);
    queue(20);
    queue(30);
    show();
    printf("Deleted: %d\n",dequeue());
    show();
    queue(40);
    show();
    return 0;
}
