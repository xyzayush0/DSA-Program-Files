#include <stdio.h>
#include <ctype.h>
int main(){
	char s[100];
	int i,j;
	printf("Enter the String=");
	gets(s);
	printf("\n");
	if (isalpha(s[0])){
		if (islower(s[0])){
			s[0]-=32;
		}
	}    
	for (j=1;s[j]!='\0';j++){
		if (s[j]==' ' && islower(s[j+1])){
			s[j+1]-=32;
		}
	}
	printf(s);
}
