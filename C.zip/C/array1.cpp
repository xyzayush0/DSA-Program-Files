#include <stdio.h>
int main(){
	int a[10];
	int i,n,avg,s=0;
	for (i=0;i<10;i++){
		printf("Enter a element");
		scanf("%d",&n);
		a[i]=n;
		s=s+n;
	}
	avg=s/10;
	for (i=0;i<10;i++){
		if (avg<a[i]){
			printf("\n %d",a[i]);
		}
	}
	return 0;
}
