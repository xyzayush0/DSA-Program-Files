#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>

#define size 20

char stk[size];
char hold[size];

int top1 = -1;
int top2 = -1;

void push1(char value)
{
    if (top1 == size - 1)
    {
        printf("Stack Overflow");
        return;
    }

    stk[++top1] = value;
}

void push2(char value)
{
    if (top2 == size - 1)
    {
        printf("Stack Overflow");
        return;
    }

    hold[++top2] = value;
}

char pop1()
{
    if (top1 == -1)
    {
        printf("Stack Underflow");
        return '\0';
    }

    return stk[top1--];
}

int precedence(char ch)
{
    if (ch == '^' || ch == '$')
    {
        return 3;
    }

    else if (ch == '*' || ch == '/' || ch == '%')
    {
        return 2;
    }

    else if (ch == '+' || ch == '-')
    {
        return 1;
    }
    else
    {
        return 0;
    }
}

void show(char value)
{
    int i;

    printf("\n%c\t\t", value);

    if (top2 == -1)
        printf("Empty");
    else
    {
        for (i = 0; i <= top2; i++)
            printf("%c", hold[i]);
    }

    printf("\t\t");

    if (top1 == -1)
        printf("Empty");
    else
    {
        for (i = 0; i <= top1; i++)
            printf("%c", stk[i]);
    }
}

int main()
{
    char s[20];
    int i;

    printf("Enter the arithmetic expression = ");
    scanf("%s", s);

    printf("\nSymbol Scan\tPostfix(Y)\tStack");

    push1('(');
    strcat(s, ")");

    for (i = 0; s[i] != '\0'; i++)
    {
        char ch = s[i];

        if (isalnum(ch))
        {
            push2(ch);
        }

        else if (ch == '(')
        {
            push1(ch);
        }

        else if (ch == ')')
        {
            while (stk[top1] != '(')
            {
                push2(pop1());
            }

            pop1();
        }

        else
        {
            while (precedence(stk[top1]) >= precedence(ch))
            {
                push2(pop1());
            }

            push1(ch);
        }

        show(ch);
    }

    printf("\n\nPostfix Expression = ");

    for (i = 0; i <= top2; i++)
    {
        printf("%c", hold[i]);
    }

    return 0;
}
