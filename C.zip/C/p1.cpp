#include<stdio.h>
#include<stdlib.h>
int main()
{
	int *a,n,i;
	printf("\n Enter the size :");
	scanf("%d",&n);
	a=(int *)malloc(sizeof(int)*n);
	//a=(int *)calloc(sizeof(int),n);
	printf("\n Enter the elements :");
	for(i=0;i<n;i++)
	{
		scanf("%d",a+i);
	}
	printf("\n Elements are :");
	for(i=0;i<n;i++)
	{
		printf("%4d",*(a+i));o
	}
}
