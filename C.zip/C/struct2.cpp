#include <stdio.h>
struct time{
	int hrs;
	int mins;
	int sec;
};
int main(){
	struct time s1;
	printf("\n Enter first time!!");
	printf("\n Enter hours minutes and seconds=");
	scanf("%d %d %d",&s1.hrs,&s1.mins,&s1.sec);
	struct time s2;
	printf("\n Enter second time!!");
	printf("\n Enter hours minutes and seconds=");
	scanf("%d %d %d",&s2.hrs,&s2.mins,&s2.sec);
	printf("\nTime 1= %d:%d:%d",s1.hrs,s1.mins,s1.sec);
	printf("\nTime 2= %d:%d:%d",s2.hrs,s2.mins,s2.sec);
	struct time s3;
	s3.hrs=s1.hrs+s2.hrs;
	s3.mins=s1.mins+s2.mins;
	s3.sec=s1.sec+s2.sec;
	if ((s3.mins)>=60){
		s3.hrs+=1;
		s3.mins-=60;
	}
	if ((s3.sec)>=60){
		s3.mins+=1;
		s3.sec-=60;
	}
	printf("\nAdded Time= %d:%d:%d",s3.hrs,s3.mins,s3.sec);
}
