#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#define size 20
int stk[size];
int top=-1;
void push(int value){
    if(top==size-1){
        printf("Stack Overflow");
        return;
    }
    stk[++top]=value;
}
int pop(){
    if(top==-1){
        printf("Stack Underflow");
        return 0;
    }
    return stk[top--];
}
int op(int a,int b,char oper){
    switch(oper){
        case '/':
            return a/b;
        case '+':
            return a+b;
        case '-':
            return a-b;
        case '*':
            return a*b;
        case '^':
            return pow(a,b);
    }
    return 0;
}

int main(){
    int ch=0,i,n,a,b,c;
    char oper[5]={'/','+','-','*','^'};
    char in[50];

    printf("Enter the expression=");
    scanf("%s",in);
    while(in[ch]!='\0'){
        n=0;
        for(i=0;i<5;i++){
            if(in[ch]==oper[i]){
                n++;
            }
        }
        if(n==0){
            push(in[ch]-'0');
        }
        else{
            b=pop();
            a=pop();
            c=op(a,b,in[ch]);
            push(c);
        }
        ch++;
    }
    printf("\nResult=%d",pop());
    return 0;
}
