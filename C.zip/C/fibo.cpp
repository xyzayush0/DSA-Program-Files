#include <stdio.h>
int main(){
	int n,i,j;
	int a=0,b=1,c;
	printf("Enter n=");
	scanf("%d",&n);
	for (i=0;i<n;i++){
		printf("%d,",a);
		c=a+b;
		a=b;
		b=c;
	}
}
