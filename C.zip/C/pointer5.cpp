#include <stdio.h>
#include <ctype.h>
#include <string.h>
int main(){
	int a=10;
	float b=2.5;
	char c='A';
	void *p=NULL;
	p=&a;
	printf("a=%d",*(int *)p);
	p=&b;
	printf("a=%d",*(int *)p);
}
