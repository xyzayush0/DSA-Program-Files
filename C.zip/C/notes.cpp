#include <stdio.h>
int main(){
	int n,i=0,a;
	int cur[]={500,200,100,50,20,10,5,2,1};
	printf("Enter Amount");
	scanf("%d",&n);
	while(n)
	{
		a=n/cur[i];
		if(a!=0)
		printf("\n %d  x  %d  =  %d",cur[i],a,cur[i]*a);
		n=n%cur[i];
		i++;
	}
}
