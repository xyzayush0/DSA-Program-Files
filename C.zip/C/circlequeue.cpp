#include <stdio.h>
#define size 5
int arr[size];
int rear=-1;
int front=-1;

void enque(int value){
	if ((front==0 && rear==size-1) || (rear+1==front)){
		printf("\nQueue Overflow\n");
		return;
	}
	if (rear==-1){
		rear=front=0;
	}
	else if (rear==size-1){
		rear=0;
	}
	else{
		rear++;
	}
	arr[rear]=value;
}

int dequeue(){
	if (front==-1){
		printf("\nQueue is empty\n");
		return 0;
	}

	int value=arr[front];

	if (rear==front){
		rear=front=-1;
	}
	else if (front==size-1){
		front=0;
	}
	else{
		front++;
	}

	return value;
}

void show(){
	int i;

	if (front==-1){
		printf("\nQueue is empty\n");
		return;
	}

	if (rear>=front){
		for (i=front;i<=rear;i++){
			printf("%4d",arr[i]);
		}
	}
	else{
		for (i=0;i<=rear;i++){
			printf("%4d",arr[i]);
		}
		for (i=front;i<size;i++){
			printf("%4d",arr[i]);
		}
	}
}

int main(){
	int n,q;
	while (1){
		printf("\nEnter your choice");
		printf("\n1.Add");
		printf("\n2.Delete");
		printf("\n3.Show");
		printf("\n4.Exit\n");
		scanf("%d",&q);
		if (q==1){
			printf("Enter value=");
			scanf("%d",&n);
			enque(n);
		}
		else if (q==2){
			n=dequeue();
			printf("%d",n);
		}
		else if (q==3){
			show();
		}
		else if (q==4){
			break;
		}
		else{
			printf("Wrong input Try again\n");
		}
	}

	return 0;
}
