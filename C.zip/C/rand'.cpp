//Store 50 random values into a 1d array and find out max and min values
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
int main(){
	int a[50];
	srand(time(0));
	int n,max,min,i;
	for (i=0;i<50;i++){
		n=rand()%100;
		a[i]=n;
	}
	max=a[0];
	min=a[0];
	for (i=0;i<50;i++){
		if (a[i]>max){
			max=a[i];
		}
		if (a[i]<min){
			min=a[i];
		}
	}
	printf("Max=%d \nMin=%d",max,min);
	return 0;
	
}
