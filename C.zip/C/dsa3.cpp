#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#define size 50
int stk[size];
int top=-1;
void push(int value)
{
    if (top == size - 1)
    {
        printf("Stack Overflow");
        return;
    }

    stk[++top] = value;
}
void show()
{
    int i;
    printf("\nStack Status:\n");
    if (top==-1)
    {
        printf("Stack is Empty");
        return;
    }
    for (i=top;i>=0;i--)
    {
        printf("%c", stk[i]);
    }
}
int main(){
	int i;
	char s[50];
	printf("Enter the string=\n");
	fgets(s,sizeof(s),stdin);
	for (i=0;s[i]!='\0';i++){
		push(s[i]);
	}
    show();
    return 0;
}
