#include <stdio.h>
#include <ctype.h>
int main(){
	char s[100];
	int k=0,end,r[10],m=0;
	int i,j,l=0;
	printf("Enter the String=");
	gets(s);
	printf("\n");
	for (i=0;s[i]!='\0';i++){+
		if (isalpha(s[i])){
			l++;
			if (l>k){
				k=l;
				m=0;
				end=i;
				r[m++]=end;
			}
			else if (l==k){
				end=i;
				r[m++]=end;
			}
		}
		else{
			l=0;
		}
	}
	for (i=0;i<m;i++){
		for (j=r[i]-k+1;j<=r[i];j++){
			printf("%c",s[j]);
		}
		printf("\n");
	}
}
