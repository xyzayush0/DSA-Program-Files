#include <stdio.h>
#include <ctype.h>
int main(){
	char s;
	printf("Enter the Character=");
	scanf("%c",&s);
	printf("\n");
	if (isalpha(s)){
		if (isupper(s)){
			printf("Alphabet-Upper");
		}
		else{
			printf("Alphabet-Lower");
		}
	}
	else if (isdigit(s)){
		printf("Digit");
		
	}
	else{
		printf("Special Character");
	}
}
