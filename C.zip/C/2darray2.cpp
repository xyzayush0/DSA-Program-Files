#include <stdio.h>
void input(int a[][10],int b[][10],int n, int m){
	int i,j;
	printf("Enter values of array 1=");
	for (i=0;i<n;i++){
		for (j=0;j<m;j++){
			scanf("%d",&a[i][j]);
		}
	}
		printf("Enter values of array 2=");
	for (i=0;i<n;i++){
		for (j=0;j<m;j++){
			scanf("%d",&b[i][j]);
		}
	}
}
void output(int a[][10],int b[][10],int c[][10],int n, int m){
	int i,j;
	printf("Array 1=\n");
	for (i=0;i<n;i++){
		for (j=0;j<m;j++){
			printf("%4d",a[i][j]);
		}
		printf("\n");
	}
	printf("Array 2=\n");
	for (i=0;i<n;i++){
		for (j=0;j<m;j++){
			printf("%4d",b[i][j]);
		}
		printf("\n");
	}
	printf("Array Product=\n");
	for (i=0;i<n;i++){
		for (j=0;j<m;j++){
			printf("%4d",c[i][j]);
		}
		printf("\n");
	}
}
void product(int a[][10],int b[][10],int c[][10],int n,int m){
	int i,j,k;
	for (i=0;i<n;i++){
		for (j=0;j<m;j++){
			c[i][j]=0;
			for (k=0;k<n;k++){
				c[i][j]+=a[i][k]*b[k][j];
			}
		}
	}
}
int main(){
	int i,j;
	int a[10][10],b[10][10],c[10][10];
	printf("Enter value of i=");
	scanf("%d",&i);
	printf("Enter value of j=");
	scanf("%d",&j);
	input(a,b,i,j);
	product(a,b,c,i,j);
	output(a,b,c,i,j);
	
}

