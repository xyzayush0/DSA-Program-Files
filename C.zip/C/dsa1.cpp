#include <stdio.h>
#include <stdlib.h>
#define size 5
int stk[size];
int top = -1;

void push(int value)
{
    if (top == size - 1)
    {
        printf("Stack Overflow");
        return;
    }

    stk[++top] = value;
}

int pop()
{
    if (top == -1)
    {
        printf("Stack Underflow");
        return 0;
    }

    return stk[top--];
}

void show()
{
    int i;

    printf("\nStack Status:\n");

    if (top == -1)
    {
        printf("Stack is Empty");
        return;
    }

    for (i = top; i >= 0; i--)
    {
        printf("%4d", stk[i]);
    }
}

int main()
{
    int ch, n;

    while (1)
    {
        printf("\n\n1. Push\n2. Pop\n3. Show\n0. Exit");
        printf("\nEnter your choice: ");
        scanf("%d", &ch);

        switch (ch)
        {
            case 0:
                exit(0);

            case 1:
                printf("\nEnter a number: ");
                scanf("%d", &n);

                push(n);
                show();
                break;

            case 2:
                n = pop();

                if (n != 0)
                {
                    printf("\nPopped Item = %d", n);
                }

                show();
                break;

            case 3:
                show();
                break;

            default:
                printf("\nWrong Input");
        }
    }

    return 0;
}
