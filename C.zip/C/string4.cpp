#include <stdio.h>
int main(){
	int i,j,k=0;
	char a[100];
	printf("Enter the String=");
	gets(a);
	for (i=0;a[i]!='\0';i++);
	for (i=i-1,j=0;j<i;i--,j++){
		if (a[i]!=a[j]){
			printf("Not Palindrome");
			k=1;
			break;
		}
	}
	if (k==0){
		printf("Palindrome");
	}
}
