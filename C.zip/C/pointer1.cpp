//Swap using pointer
#include <stdio.h>
void swap(int *p1,int *p2){
	int t;
	t=*p2;
	*p2=*p1;
	*p1=t;
	
}
int main(){
	int a,b;
	printf("\nEnter 2 nos=");
	scanf("%d %d",&a,&b);
	swap(&a,&b);
	printf("Num 1= %d\n Num 2=%d",a,b);
}
