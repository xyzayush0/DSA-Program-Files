#include <stdio.h>
#include <ctype.h>
int main(){
	char a[][13] = {"I","IV","V","IX","X","XL","L","XC","C","CD","D","CM","M"};
	int b[13]={1,4,5,9,10,40,50,90,100,400,500,900,1000};
	int n,i=12;
	printf("Enter Number=");
	scanf("%d",&n);
    while (n>0){
    	while (n>=b[i]){
    		printf("%s",a[i]);
    		n-=b[i];
		}
		i--;
	}
}
