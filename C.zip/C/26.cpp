#include <stdio.h>
int main(){
	int b[10];
	b[0]=1;
	printf("%d",b[4]);
}
